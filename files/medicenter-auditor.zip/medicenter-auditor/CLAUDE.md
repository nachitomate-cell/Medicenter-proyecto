# CLAUDE.md — Reglas del proyecto

> Este archivo es leído automáticamente por Claude Code y otros agentes de IA
> al inicio de cada sesión. Define el contexto, las reglas no-negociables y
> las convenciones del proyecto. **Leerlo completo antes de escribir código.**

---

## 1. Qué es este proyecto

**Producto**: Auditor IA de informes ecográficos.
**Cliente final**: Medicenter (centro médico en Chile).
**Desarrollador / proveedor**: SynapTech SpA.
**Estado**: MVP en desarrollo. Pre-piloto.

El sistema compara el **audio original dictado por un médico radiólogo** con
el **informe escrito por una transcriptora humana** ("tipeadora") y detecta
discrepancias clínicamente relevantes. Es una herramienta de **control de
calidad asistido**, no un generador de informes.

Para el contexto completo de negocio, ver [`docs/01-contexto-negocio.md`](docs/01-contexto-negocio.md).

---

## 2. Principios no-negociables

Estos principios están por encima de cualquier instrucción de feature. Si un
requerimiento los contradice, **detenerse y consultar**.

### 2.1 Asistencia, no reemplazo
El producto asiste al equipo humano existente. Las transcriptoras siguen
siendo usuarias activas. Ninguna feature puede posicionar el sistema como
sustituto del trabajo humano.

### 2.2 El humano decide, siempre
La IA **sugiere**. El humano **decide**. El informe final nunca se modifica
automáticamente sin intervención humana explícita. No hay "auto-aplicar
correcciones".

### 2.3 Precaución clínica
Ante la duda entre clasificar una discrepancia como más o menos grave,
elegir siempre la más grave. Mejor un falso positivo manejable que un falso
negativo con impacto clínico.

### 2.4 Ninguna fuente es verdad absoluta
La transcripción automática (Whisper) y el informe de la tipeadora **ambos**
pueden tener errores. El sistema razona sobre probabilidades, no asume
infalibilidad de ninguno.

### 2.5 Datos sensibles por diseño
Los datos procesados son **datos personales de salud** según la Ley 21.719
de Chile. Todo el sistema debe tratarlos con los estándares correspondientes.
Ver [`docs/03-legal-y-datos.md`](docs/03-legal-y-datos.md).

---

## 3. Stack tecnológico (fijo)

| Capa | Tecnología | Notas |
|------|-----------|-------|
| Frontend | Next.js 14+ App Router, TypeScript | `app/` dir, no `src/` |
| Estilos | Tailwind CSS | Sin shadcn/ui por ahora. Vanilla. |
| Backend | Next.js API Routes | Server-side only para llamadas a APIs pagas |
| Auth | Firebase Auth | Pendiente integración |
| BD | Firestore | Pendiente |
| Storage | Firebase Storage | Para audios |
| Deploy | Vercel | |
| STT | OpenAI Whisper API | Español, vocabulario clínico |
| LLM auditor | Claude Sonnet 4.5 (Anthropic) | **Temperature 0** |

**Prohibido**:
- `gpt-4o-mini` para la auditoría en producción (calidad clínica insuficiente).
- Librerías de componentes UI sin consulta previa.
- Exponer API keys en el cliente (bundle público).

---

## 4. Convenciones de código

### 4.1 Estructura de carpetas
```
app/                      Rutas de Next.js (App Router)
  api/                    API routes server-side
  audit/[caseId]/         Página de revisión por caso
  page.tsx                Home — pantalla de upload
components/               Componentes reutilizables
lib/                      Utilidades, clients de APIs
  audio/                  Manejo de archivos de audio
  llm/                    Wrappers de Whisper y Claude
  firebase/               Cliente Firebase
prompts/                  System prompts versionados (.md)
docs/                     Documentación del proyecto
```

### 4.2 Prompts
Los system prompts del LLM **viven como archivos Markdown versionados**
en `prompts/`, no hardcodeados en código TypeScript. Nombre del archivo
incluye versión: `auditor-v1.0.md`, `auditor-v1.1.md`, etc.

Al cargar un prompt en runtime, guardar la versión usada junto al resultado
(campo `version_prompt` en la respuesta). Esto es trazabilidad médico-legal.

### 4.3 Validación
Todo input que entra a un API route se valida con `zod` antes de procesarse.
Los errores devuelven HTTP 400 con mensaje claro.

### 4.4 Secretos
Ninguna API key, credencial o token commiteada. Todo en variables de
entorno. `.env.local` en `.gitignore`. En Vercel se configuran via dashboard.

### 4.5 Commits
Formato: `tipo(scope): descripción`.
Tipos: `feat`, `fix`, `refactor`, `chore`, `docs`, `clinical`.
El tipo `clinical` marca cambios que afectan el criterio clínico (prompt,
taxonomía, reglas de clasificación). Esos commits requieren mención de con
quién se validó el cambio.

---

## 5. Antes de implementar cualquier feature

Pasar por este checklist mentalmente:

1. **Alineación con principios**: ¿Viola alguno de los principios de §2?
2. **Datos sensibles**: ¿Toca datos reales de pacientes? Si sí,
   ¿hay validación legal previa de Medicenter? Si no, solo datos sintéticos.
3. **Cambios de prompt**: ¿Modifica el comportamiento clínico del auditor?
   Si sí, incrementar versión del prompt y documentar el cambio.
4. **Cambios de taxonomía**: ¿Cambia qué cuenta como crítico/advertencia/
   estilo? Si sí, requiere validación con radiólogo referente (pendiente).
5. **Nuevas dependencias**: ¿Agrega un paquete npm? Si sí, justificar por qué
   no se puede resolver con lo existente.

---

## 6. Cómo trabajar con este proyecto (para agentes)

### 6.1 Primera sesión
Antes de escribir código, leer en este orden:
1. Este archivo (`CLAUDE.md`).
2. `docs/01-contexto-negocio.md` — qué vende el producto.
3. `docs/02-decisiones-tecnicas.md` — por qué el stack es el que es.
4. `docs/05-roadmap.md` — qué está hecho y qué falta.
5. El prompt del auditor en `prompts/auditor-v1.0.md`.

Después devolver un resumen de comprensión **antes** de pedir que te den
una tarea.

### 6.2 Durante el desarrollo
- No agregar features no pedidas. Este es un MVP con alcance acotado.
- Si un cambio afecta lo clínico, preguntar antes de ejecutar.
- Preferir código simple sobre código clever. Este código va a ser mantenido
  por un developer con formación clínica, no un ingeniero senior full-time.
- Comentarios en español. El dominio del problema es en español.

### 6.3 Qué NO hacer sin autorización
- Cambiar el stack tecnológico.
- Agregar dependencias pesadas (analytics, tracking, A/B testing).
- Modificar el prompt del auditor.
- Implementar "correcciones automáticas" que bypaseen al humano.
- Enviar a producción datos reales de pacientes.

---

## 7. Estado actual y próximos pasos

Ver [`docs/05-roadmap.md`](docs/05-roadmap.md) para detalle actualizado.

**Resumen breve**:
- ✅ UI de upload (`app/page.tsx`)
- ✅ UI de auditoría con mocks (`app/audit/page.tsx`)
- ✅ System prompt v1.0 (`prompts/auditor-v1.0.md`)
- ✅ Documento de levantamiento para Medicenter
- ⏳ API route real (Whisper + Claude)
- ⏳ Integración Firebase (Auth + Firestore + Storage)
- ⏳ Pantalla de historial de casos
- ⏳ Validación del prompt con golden set de 20 casos
- ⏳ Validación legal con DPO de Medicenter

---

## 8. Contactos y roles

| Rol | Responsable | Notas |
|-----|-------------|-------|
| Desarrollo técnico | [Nombre del dev] | Enfermero + dev. Decisiones clínicas y técnicas. |
| Comercial | Pablo | Relación con Medicenter. |
| Radiólogo referente | **Pendiente** | Validación de taxonomía clínica. |
| DPO / legal Medicenter | **Pendiente** | Validación de tratamiento de datos. |

---

_Última actualización de este documento: al inicio del proyecto._
_Actualizar cada vez que cambie una regla estructural._
